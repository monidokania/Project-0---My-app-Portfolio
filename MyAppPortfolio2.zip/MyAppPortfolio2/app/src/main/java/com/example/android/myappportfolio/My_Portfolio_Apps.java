package com.example.android.myappportfolio;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;
import android.widget.Button;
public class My_Portfolio_Apps extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my__portfolio__apps);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        /*FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_my__portfolio__apps, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    public void changeColor(String VIEW_NAME)
    {
        Button btn = (Button)findViewById(getResources().getIdentifier(VIEW_NAME, "id", getPackageName()));
        //Button btn = (Button) findViewById(R.id.btn_breader);
        btn.setTextColor(-1);

    }
    public void showSpotify(View v){
        changeColor("btn_spotify");
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my Spotify Streamer App", Toast.LENGTH_LONG);
        toast.show();
    }
    public void showScores(View view){
        changeColor("btn_scores");
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my Scores App", Toast.LENGTH_LONG);
        toast.show();
    }

    public void showLibrary(View view){
        changeColor("btn_lib");
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my Library App", Toast.LENGTH_LONG);
        toast.show();
    }

    public void showBuild(View view){
        changeColor("btn_buildBig");
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my Build-It-Bigger App", Toast.LENGTH_LONG);
        toast.show();
    }

    public void showBacon(View view){
        changeColor("btn_breader");
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my Bacon Reader App", Toast.LENGTH_LONG);
        toast.show();
    }

    public void showCapstone(View view){
        Toast toast = Toast.makeText(getApplicationContext(), "This button will launch my CapStone App", Toast.LENGTH_LONG);
        toast.show();
    }

}
